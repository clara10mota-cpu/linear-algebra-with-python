
""" Exercício 2: Operações com Matrizes"""

import numpy as np

""" DEFINIR AS MATRIZES A E B : """

A = np.array([[1, 2, 3],
              [4, 5, 6]])

B = np.array([[6, 5, 4],
              [3, 2, 1]])

C = np.array([[1, 0],
              [0, 1],
              [1, 1]])

""" Definir matrizes P e Q (2x2) """

P = np.array([[1, 2],
              [3, 4]])

Q = np.array([[0, 1],
              [1, 0]])

""" Matriz identidade 2x2 : """
I = np.eye(2)          
PI = np.dot(P, I)
IP = np.dot(I, P)


""" REALIZAR AS OPERAÇÕES : """
soma = A + B
subtracao = A - B
multiplicacao = 3 * A
AC = np.dot(A, C)  # (2x3) · (3x2) = (2x2)
CA = np.dot(C, A)  # (3x2) · (2x3) = (3x3)
PQ = np.dot(P, Q)
QP = np.dot(Q, P)

""" Comutador [P, Q] = PQ - QP """
comutador = PQ - QP


""" VERIFICAR SE AS DIMENSÕES SÃO RESERVADAS :"""
assert soma.shape == A.shape == B.shape

""" IMPRMIR RESULTADOS : """

print("A + B:\n", soma)
print("A - B:\n", subtracao)
print("3A:\n", multiplicacao)
print("A x C:\n", AC)
print("Dimensão de AC:", AC.shape)
print("C x A:\n", CA)
print("Dimensão de CA:", CA.shape)
print("\nP x Q:\n", PQ)
print("Q x P:\n", QP)
print("\nComutador [P, Q] = PQ - QP:\n", comutador)
print("\nP x I:\n", PI)
print("I x P:\n", IP)



print("Dimensões preservadas!")

